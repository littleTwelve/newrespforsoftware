﻿// 模型“C:\Users\Administrator\documents\visual studio 2012\Projects\StudentGradeManagementSystem\StudentGradeManagementSystem\StudentGradeMS.edmx”的默认代码生成功能已禁用。
// 要启用默认代码生成功能，请将“代码生成策略”设计器属性的值
// 更改为另一值。当在设计器中打开该模型时，此属性会出现在
// “属性”窗口中。